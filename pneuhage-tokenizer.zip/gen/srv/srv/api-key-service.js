const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {

    const { APIKeys } = this.entities;

    this.on('generateAPIKey', async (req) => {
        // Generiere einen zufälligen API Key
        const apiKey = generateRandomAPIKey();

        // Füge den Key in die Datenbank ein
        const result = await INSERT.into(APIKeys).entries({
            ID: cds.utils.uuid(),
            apiKey: apiKey,
            createdAt: new Date()
        });

        return result;
    })

// Funktion zur Generierung eines zufälligen API-Keys
function generateRandomAPIKey() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let apiKey = '';
    for (let i = 0; i < 32; i++) {
        apiKey += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return apiKey;
}
  
    // Die Methode zur Validierung des API-Keys und Rückgabe des Debitors
    this.on('validateAPIKey', async (req) => {
      const apiKey = req.data.apiKey.value;  // Extrahiere den apiKey-Wert aus dem verschachtelten Objekt
    
      // Suche nach dem APIKey in der Datenbank und selektiere die gewünschten Felder
      const result = await SELECT.one(['debitor', 'Textfield', 'createdAt']).from(APIKeys).where({ apiKey });
    
      // Wenn der APIKey gefunden wird
      if (result) {
        // Rückgabe: true, debitor, Textfield, createdAt
        return { 
          valid: true, 
          debitor: result.debitor, 
          Textfield: result.Textfield, 
          createdAt: result.createdAt 
        };
      } else {
        // API-Key ungültig, Rückgabe des HTTP-Fehlercodes 401
        const error = new Error('Unauthorized');
        error.status = 401; // HTTP Status Code für "Unauthorized"
        throw error; // Werfen des Fehlers
      }
    });
      /*
      Syntax des Request:
      http://localhost:4004/odata/v4/apikey/validateAPIKey
      Body(JSON):
            {
          "apiKey": {
              "value": "putApiKeyHere"
          }
      }
      */   
  })
